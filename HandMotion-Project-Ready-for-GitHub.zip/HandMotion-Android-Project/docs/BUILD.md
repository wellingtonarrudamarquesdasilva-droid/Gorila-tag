# Como avançar até o APK

## Opção A — testar o rastreador Android
1. Abra `android-hand-tracker/` no Android Studio.
2. Use uma versão compatível do Android Gradle Plugin/Gradle e SDK Android.
3. Aguarde a sincronização das dependências.
4. Conecte um Android com depuração USB ou use um emulador com câmera.
5. Compile e execute o módulo `app`.

O modelo MediaPipe `hand_landmarker.task` deve ser colocado em:
`android-hand-tracker/app/src/main/assets/hand_landmarker.task`

O arquivo do modelo não está incluído neste ZIP. Baixe o modelo oficial Hand Landmarker da documentação do MediaPipe e confira a licença/termos antes de distribuir.

## Opção B — protótipo Unity
1. Abra `unity-prototype/` no Unity Hub.
2. Crie/abra uma cena e adicione um `CharacterController` ao jogador.
3. Adicione `MobileGameControls` ao jogador ou a um objeto de UI.
4. Adicione `GyroCameraLook` à câmera.
5. Adicione `MobilePlayerController` ao jogador e associe a câmera.
6. Adicione `HandUdpReceiver` a um objeto vazio.
7. Adicione `ProceduralArmRig` e associe os transforms/objetos de braço necessários.
8. Configure Android como plataforma de build.

Os scripts são uma base de protótipo. A cena, os materiais, os modelos 3D e a ponte integrada de MediaPipe ainda precisam ser montados/testados.

## Para compilar na nuvem
Um serviço de build pode compilar um projeto Android/Unity quando o projeto está completo e suas dependências/licenças estão configuradas. O ZIP atual, sozinho, ainda não produz o jogo final de um clique.
