using UnityEngine;

// Protótipo visual: usa pontos fornecidos no Inspector; ombro/cotovelo são estimados.
public class ProceduralArmRig : MonoBehaviour
{
    public HandUdpReceiver receiver;
    public Transform leftShoulder, leftElbow, leftWrist;
    public Transform rightShoulder, rightElbow, rightWrist;
    public float reach = 1.2f;
    public float elbowBend = 0.25f;

    void Update()
    {
        if (receiver == null) return;
        if (receiver.hasLeft) MoveArm(receiver.leftHand, leftShoulder, leftElbow, leftWrist);
        if (receiver.hasRight) MoveArm(receiver.rightHand, rightShoulder, rightElbow, rightWrist);
    }

    void MoveArm(Vector2 hand, Transform shoulder, Transform elbow, Transform wrist)
    {
        if (!shoulder || !elbow || !wrist) return;
        Vector3 target = new Vector3((hand.x - 0.5f) * reach * 2f,
            (0.5f - hand.y) * reach * 2f, 0.7f);
        Vector3 worldTarget = shoulder.parent ? shoulder.parent.TransformPoint(target) : target;
        wrist.position = worldTarget;
        elbow.position = Vector3.Lerp(shoulder.position, wrist.position, 0.5f)
                         + Vector3.down * elbowBend;
    }
}
