using UnityEngine;

public class GyroCameraLook : MonoBehaviour
{
    public bool enabledGyro = true;
    public float sensitivity = 1f;
    Quaternion initialRotation;

    void Start()
    {
        initialRotation = transform.localRotation;
        if (SystemInfo.supportsGyroscope) Input.gyro.enabled = true;
    }

    void Update()
    {
        if (!enabledGyro || !SystemInfo.supportsGyroscope) return;
        Quaternion attitude = Input.gyro.attitude;
        Quaternion corrected = new Quaternion(attitude.x, attitude.y, -attitude.z, -attitude.w);
        transform.localRotation = initialRotation * Quaternion.Slerp(Quaternion.identity, corrected, sensitivity);
    }

    public void Recenter() { initialRotation = transform.localRotation; }
}
