using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class MobileGameControls : MonoBehaviour
{
    [Header("State read by your controller")]
    public Vector2 moveInput;
    public bool jumpPressed, leftHandPressed, rightHandPressed;
    public bool gyroEnabled = true;

    void Start()
    {
        // A UI Canvas/EventSystem must exist in the scene. This script creates simple buttons.
        if (FindObjectOfType<EventSystem>() == null) new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        Canvas canvas = FindObjectOfType<Canvas>();
        if (canvas == null) {
            var go = new GameObject("MobileControlsCanvas");
            canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            go.AddComponent<CanvasScaler>();
            go.AddComponent<GraphicRaycaster>();
        }
        CreateButton(canvas.transform, "PULAR", new Vector2(0.82f, 0.22f), () => jumpPressed = true, () => jumpPressed = false);
        CreateButton(canvas.transform, "MÃO E", new Vector2(0.68f, 0.12f), () => leftHandPressed = true, () => leftHandPressed = false);
        CreateButton(canvas.transform, "MÃO D", new Vector2(0.92f, 0.12f), () => rightHandPressed = true, () => rightHandPressed = false);
        CreateButton(canvas.transform, "GIRO", new Vector2(0.88f, 0.36f), () => gyroEnabled = !gyroEnabled, null);
    }

    void CreateButton(Transform parent, string label, Vector2 anchor, System.Action down, System.Action up)
    {
        var go = new GameObject(label);
        go.transform.SetParent(parent, false);
        var image = go.AddComponent<Image>();
        image.color = new Color(0.08f, 0.18f, 0.28f, 0.75f);
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = anchor;
        rect.sizeDelta = new Vector2(130, 64);
        var textGo = new GameObject("Text");
        textGo.transform.SetParent(go.transform, false);
        var text = textGo.AddComponent<Text>();
        text.text = label; text.alignment = TextAnchor.MiddleCenter; text.color = Color.white;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.rectTransform.anchorMin = Vector2.zero; text.rectTransform.anchorMax = Vector2.one;
        text.rectTransform.offsetMin = text.rectTransform.offsetMax = Vector2.zero;
        var trigger = go.AddComponent<EventTrigger>();
        AddEvent(trigger, EventTriggerType.PointerDown, _ => down?.Invoke());
        if (up != null) {
            AddEvent(trigger, EventTriggerType.PointerUp, _ => up.Invoke());
            AddEvent(trigger, EventTriggerType.PointerExit, _ => up.Invoke());
        }
    }

    void AddEvent(EventTrigger trigger, EventTriggerType type, System.Action<BaseEventData> action)
    {
        var entry = new EventTrigger.Entry { eventID = type };
        entry.callback.AddListener(data => action(data));
        trigger.triggers.Add(entry);
    }
}
