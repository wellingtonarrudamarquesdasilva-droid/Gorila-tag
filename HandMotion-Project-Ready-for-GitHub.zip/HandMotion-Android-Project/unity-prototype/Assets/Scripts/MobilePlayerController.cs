using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class MobilePlayerController : MonoBehaviour
{
    public MobileGameControls controls;
    public Transform cameraTransform;
    public float speed = 4f;
    public float jumpHeight = 1.2f;
    public float gravity = -18f;
    CharacterController controller;
    Vector3 velocity;

    void Start() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        Vector2 input = controls ? controls.moveInput : Vector2.zero;
        Vector3 forward = cameraTransform ? cameraTransform.forward : transform.forward;
        Vector3 right = cameraTransform ? cameraTransform.right : transform.right;
        forward.y = 0; right.y = 0;
        Vector3 move = (forward.normalized * input.y + right.normalized * input.x);
        controller.Move(move * speed * Time.deltaTime);

        if (controller.isGrounded && velocity.y < 0) velocity.y = -2f;
        if (controls && controls.jumpPressed && controller.isGrounded)
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }
}
