using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;

public class HandUdpReceiver : MonoBehaviour
{
    public int port = 5055;
    public Vector2 leftHand;
    public Vector2 rightHand;
    public bool hasLeft;
    public bool hasRight;

    UdpClient client;
    Thread thread;
    volatile string latest = "";

    void Start()
    {
        client = new UdpClient(port);
        thread = new Thread(ReceiveLoop) { IsBackground = true };
        thread.Start();
    }

    void ReceiveLoop()
    {
        var endpoint = new IPEndPoint(IPAddress.Any, port);
        while (client != null)
        {
            try { latest = Encoding.UTF8.GetString(client.Receive(ref endpoint)); }
            catch { break; }
        }
    }

    void Update()
    {
        if (string.IsNullOrEmpty(latest)) return;
        // Formato esperado: L:x,y;R:x,y
        string packet = latest;
        latest = "";
        foreach (var part in packet.Split(';'))
        {
            var pair = part.Split(':');
            if (pair.Length != 2) continue;
            var xy = pair[1].Split(',');
            if (xy.Length != 2 || !float.TryParse(xy[0], System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out float x) ||
                !float.TryParse(xy[1], System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out float y)) continue;
            if (pair[0] == "L") { leftHand = new Vector2(x, y); hasLeft = true; }
            if (pair[0] == "R") { rightHand = new Vector2(x, y); hasRight = true; }
        }
    }

    void OnDestroy()
    {
        try { client?.Close(); } catch { }
        client = null;
        try { thread?.Join(100); } catch { }
    }
}
