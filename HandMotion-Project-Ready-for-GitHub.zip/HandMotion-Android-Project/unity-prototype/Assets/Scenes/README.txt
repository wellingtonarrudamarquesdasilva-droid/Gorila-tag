Crie uma cena no Unity, adicione Player com CharacterController, câmera, Canvas e os scripts descritos em docs/BUILD.md.
