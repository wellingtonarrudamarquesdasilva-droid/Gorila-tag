# HandMotion – projeto-fonte (protótipo)

Este pacote reúne a base Android de rastreamento de mãos e os scripts Unity de protótipo para controles móveis e braços 3D.

**Importante:** este pacote é código-fonte, não é um APK pronto. A integração final entre o rastreamento MediaPipe e o Unity ainda precisa ser feita e testada antes de uma compilação de produção.

## Conteúdo
- `android-hand-tracker/`: aplicativo Android Kotlin com CameraX e MediaPipe Tasks Vision (rastreamento de até duas mãos pela câmera traseira).
- `unity-prototype/Assets/Scripts/`: scripts de exemplo para receber coordenadas UDP, representar braços, joystick, botões e giroscópio.
- `docs/BUILD.md`: próximos passos de compilação.

## Limitações conhecidas
1. O app Android e o protótipo Unity são dois projetos separados.
2. O envio UDP para `127.0.0.1:5055` é uma ponte de demonstração; não garante que dois apps consigam usar a câmera/ficar ativos simultaneamente.
3. O projeto Unity precisa de uma cena, personagem, câmera e configuração Android.
4. Para um único APK final, o rastreador MediaPipe precisa ser integrado ao Unity (por exemplo, via plugin Android/AAR) ou o jogo precisa ser implementado inteiramente como app Android nativo.
5. Os pontos de cotovelo/ombro são estimativas visuais; o rastreador detecta as mãos, não o corpo inteiro.

Este projeto é independente e não contém código, assets ou arquivos proprietários do Gorilla Tag.
